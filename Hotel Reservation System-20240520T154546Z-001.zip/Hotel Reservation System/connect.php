<?php
    $host = "localhost";
    $username ="root";
    $password ="";
    $database ="safaya";
    $port = "3306";

    $connection = mysqli_connect($host, $username, $password, $database, $port);

    if(!$connection){
        die("Not connected to the database");
    }
?>