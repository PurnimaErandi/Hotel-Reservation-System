<?php

    require("connect.php");

    if(isset($_POST["submit"])){
        $name =$_POST["name"];
        $nic =$_POST["nic"];
        $email =$_POST["email"];
        $checkin =$_POST["checkin"];
        $checkout =$_POST["checkout"];
        $rooms =$_POST["rooms"];
    }

?>